#include "Apartamento.h"

Apartamento::Apartamento()
{

}

Apartamento::Apartamento(std::string posicao, std::string numQuartos, std::string valorCondominio, std::string vagasGaragem, std::string area, Endereco enderecoDaCasa){
    setPosicao(posicao);
    setNumQuartos(numQuartos);
    setValorCondominio(valorCondominio);
    setVagasGaragem(vagasGaragem);
    setArea(area);
    setEndereco(enderecoDaCasa);
}

//-----------------------------  SETS  -----------------------------
void Apartamento::setPosicao(std::string posicao){
    this->posicao = posicao;
}

void Apartamento::setNumQuartos(std::string numQuartos){
    this->numQuartos = numQuartos;
}

void Apartamento::setValorCondominio(std::string valorCondominio){
    this->valorCondominio = valorCondominio;
}

void Apartamento::setVagasGaragem(std::string vagasGaragem){
    this->vagasGaragem = vagasGaragem;
}

void Apartamento::setArea(std::string area){
    this->area = area;
}

//-----------------------------  GETS  -------------------------------
std::string Apartamento::getPosicao(){
    return posicao;
}

std::string Apartamento::getNumQuartos(){
    return numQuartos;
}

std::string Apartamento::getValorCondominio(){
    return valorCondominio;
}

std::string Apartamento::getVagasGaragem(){
    return vagasGaragem;
}

std::string Apartamento::getArea(){
    return area;
}

std::string Apartamento::getApartamento(){
    return getEndereco() +
    "\n  Posi��o: " + posicao +
    "\n  N�mero de quarto(s):  " + numQuartos +
    "\n  Valor do condom�nio:  " + valorCondominio +
    "\n  Vagas da garagem:  " + vagasGaragem +
    "\n  �rea:  " + area;
}
